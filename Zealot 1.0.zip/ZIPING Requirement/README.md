# Drowsiness Detection Project
Overview and project goals

Installation instructions: dependencies, environment setup .env

Usage: how to run detectors individually or full pipeline

Notes about environment variables and resource files